package com.yahdira.desarrollandoactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class Activity2 extends AppCompatActivity {
    TextView txt1;
    TextView txt2;
    TextView txt3;
    TextView txt4;
    TextView txt5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        txt1 = (TextView)findViewById(R.id.recieveFullName);
        txt2 = (TextView)findViewById(R.id.recieveDateOfBirth);
        txt3 = (TextView)findViewById(R.id.recievePhone);
        txt4 = (TextView)findViewById(R.id.recieveEmail) ;
        txt5 = (TextView)findViewById(R.id.recieveDescription);

        Bundle b1 = getIntent().getExtras();
        String s1 = b1.getString("user");
        txt1.setText(s1);
        Bundle b2 = getIntent().getExtras();
        String s2 = b1.getString("date");
        txt2.setText(s2);
        Bundle b3 = getIntent().getExtras();
        String s3 = b3.getString("phone");
        txt3.setText(s3);
        Bundle b4 = getIntent().getExtras();
        String s4 = b4.getString("email");
        txt4.setText(s4);
        Bundle b5 = getIntent().getExtras();
        String s5 = b5.getString("description");
        txt5.setText(s5);

    }

    public void goback(View view) {
        Intent i1 = new Intent(this, MainActivity.class);
        i1.putExtra("user",txt1.getText().toString());
        i1.putExtra("date",txt2.getText().toString());
        i1.putExtra("phone",txt3.getText().toString());
        i1.putExtra("email",txt4.getText().toString());
        i1.putExtra("description",txt5.getText().toString());
        setResult(RESULT_OK, i1);
        finish();

    }


}
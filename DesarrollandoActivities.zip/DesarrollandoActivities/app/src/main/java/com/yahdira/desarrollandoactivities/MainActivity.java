package com.yahdira.desarrollandoactivities;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    EditText e1;
    EditText e2;
    EditText e3;
    EditText e4;
    EditText e5;
    //datepicker
    private static final String TAG = "MainActivity";
    private TextView mDisplayDate;
    private DatePickerDialog.OnDateSetListener mDateSetListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1 = (EditText) findViewById(R.id.InputFullName);
        e2 = (EditText) findViewById(R.id.InputDateOfBirth) ;
        e3 = (EditText) findViewById(R.id.InputPhoneNumber) ;
        e4 = (EditText) findViewById(R.id.InputEmailAddress) ;
        e5 = (EditText) findViewById(R.id.InputDescription) ;

        //datepicker
        mDisplayDate = (TextInputEditText) findViewById(R.id.InputDateOfBirth);
        mDisplayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog dialog = new DatePickerDialog(
                        MainActivity.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        mDateSetListener,
                        year, month, day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });
        //datepicker
        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                Log.d(TAG, "onDateSet: date: mmm/dd/yyyy: "+ month +"/" + day + "/" + year);

                String date = month + "/" + day + "/" + year;
                mDisplayDate.setText(date);

            }
        };
    }

    public void gotoEditContact(View view) {
        Intent i1 = new Intent(this, Activity2.class);
        i1.putExtra("user",e1.getText().toString());
        i1.putExtra("date",e2.getText().toString());
        i1.putExtra("phone",e3.getText().toString());
        i1.putExtra("email",e4.getText().toString());
        i1.putExtra("description",e5.getText().toString());
        //startActivity(i1);
        startActivityForResult(i1,1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            if (resultCode == RESULT_OK){
                String i1 = data.getStringExtra("user");
                e1.setText(i1);
                String i2 = data.getStringExtra("date");
                e2.setText(i2);
                String i3 = data.getStringExtra("phone");
                e3.setText(i3);
                String i4 = data.getStringExtra("email");
                e4.setText(i4);
                String i5 = data.getStringExtra("description");
                e5.setText(i5);
            }
        }
    }
}
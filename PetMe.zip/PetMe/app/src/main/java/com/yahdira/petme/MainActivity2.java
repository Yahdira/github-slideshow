package com.yahdira.petme;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    RecyclerView recyclerViewC;
    ArrayList<Pets> Pets;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        ActionBar actionBar = getActionBar();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        recyclerViewC = (RecyclerView)findViewById(R.id.recyclerViewC);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerViewC.setLayoutManager(llm);
        initrecycleview();
        initadapter();
    }
    public MyAdapter adapter;
    private void initadapter() {
        //MyAdapter
        adapter = new MyAdapter(Pets,this, this);
        recyclerViewC.setAdapter(adapter);
    }
    private void initrecycleview() {
        Pets = new ArrayList<Pets>();
        Pets.add(new Pets("Chamaleon", R.drawable.chameleon));
        Pets.add(new Pets("Beagle",R.drawable.beagle));
        Pets.add(new Pets("BullTerrier",R.drawable.bullterrier));
        Pets.add(new Pets("Malinois", R.drawable.malinois));
        Pets.add(new Pets("Rodhesian RidgeBack", R.drawable.rhodesianridgback));
        
    }

}
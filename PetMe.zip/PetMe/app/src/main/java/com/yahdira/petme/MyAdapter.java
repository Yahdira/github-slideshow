package com.yahdira.petme;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.icu.text.Transliterator;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyHolder> {
    Context c;
    ArrayList<Pets> Pets;
    Activity activity;

    public MyAdapter(ArrayList<Pets>Pets,Activity activity, Context c){
        this.Pets = Pets;
        this.activity= activity;
        this.c = c;
    }
    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewGroup) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.my_recycler_view,parent,false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyHolder holder, final int position) {
        final Pets pets = Pets.get(position);
        holder.imagePet.setImageResource(pets.getImage());
        holder.textPetName.setText(pets.getPetname());
        holder.imageButton.setPressed(pets.isFavorite());
//agregando contador
       holder.imageButton.setOnClickListener(new View.OnClickListener(){
           int Count;
            @Override
            public void onClick(View v) {
                Count =0;
                Pets.get(position).setCount(Pets.get(position).getCount()+1);
                holder.raiting.setText(String.valueOf(Pets.get(position).getCount()));

                Toast.makeText(activity, "Raiting on: " + pets.getPetname(),Toast.LENGTH_SHORT).show();
            }
        });
        holder.raiting.setText(String.valueOf(Pets.get(position).getCount()));
    }

    @Override
    public int getItemCount() {
        return Pets.size();
    }

    public static class MyHolder extends RecyclerView.ViewHolder  {

        private ImageView imagePet;
        private TextView textPetName;
        private ImageButton imageButton;
        private TextView raiting;


        public MyHolder(@NonNull View itemView) {
            super(itemView);
            imagePet = (ImageView) itemView.findViewById(R.id.petImage);
            textPetName = (TextView) itemView.findViewById(R.id.petName);
            imageButton = (ImageButton)itemView.findViewById(R.id.imageButton);
            raiting = (TextView)itemView.findViewById(R.id.raiting);

         }

    }
}

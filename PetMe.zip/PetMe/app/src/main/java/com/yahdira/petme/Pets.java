package com.yahdira.petme;

import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

public class Pets extends AppCompatActivity {
    private String petname;
    private int image;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    private int count;
    private boolean isFavorite;

     public Pets(String petname, int image) {
        this.petname = petname;
        this.image = image;


    }

    public String getPetname() {

        return petname;
    }

    public void setPetname(String petname) {

        this.petname = petname;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {

        this.image = image;
    }

    public boolean isFavorite(){
        return isFavorite;
    }
    public void setFavorite(boolean favorite){
        isFavorite = favorite;
    }
}
